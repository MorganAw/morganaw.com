#include <iostream>
#include <iomanip>
#include "aes.cpp"
using namespace std;

int main(){
    unsigned char* input = new unsigned char[16];
    unsigned char* key = new unsigned char[176];
    cout << "Input plaintext: ";
    for(int counter = 0; counter < 16; counter++){
	cin >> noskipws >> input[counter];
    }
    cin >> key[0];
    cout << "Input key: ";
    for(int counter = 0; counter < 16; counter++){
	cin >> noskipws >> key[counter];
    }
    cout << endl;

    // Print out input and key for dexterity's sake
    cout << "Input in hex is:" << endl;
    for(int counter = 0; counter < 16; counter++){
	cout << counter << ": ";
	cout << hex << (int)input[counter] << dec << endl;
    }
    cout << "Key in hex it:" << endl;
    for(int counter = 0; counter < 16; counter++){
	cout << counter << ": ";
	cout << hex << (int)key[counter] << dec << endl;
    }

    aes(input, key);

    cout << "Your ciphertext is:" << endl;
    for(int counter2 = 0; counter2 < 16; counter2++){
	cout << counter2 << ": ";
	cout << hex << (int)input[counter2] << dec << endl;
    }
    return 0;
}
