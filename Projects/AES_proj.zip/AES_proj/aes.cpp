/* Main Function for AES implementation
 * Created By: Morgan Aw
 * Course: CSE 178 - Computer and Network Security
 * Takes 2 inputs:
 *  - pointer to first element in a 256 bit (16 char) plaintext array
 *  - pointer to first element in a 2816 bit (276 char) roundKey array
 *    -> Only first 256 bits (16 chars) are initialized to the initial roundKey
 * Additional Information:
 * ~~~ Matrix Format (visualization from array indices) ~~~
 * [ 0, 4,  8, 12 ]
 * [ 1, 5,  9, 13 ]
 * [ 2, 6, 10, 14 ]
 * [ 3, 7, 11, 15 ]
 * Note: Same for key format except key has array size of 176
 */
#include "aes.h"

using namespace std;

void aes(unsigned char* input, unsigned char* roundKey){
    // Expand initial roundKey to full 10 rounds
    roundKeyGen(roundKey);
    /* ~~~ AES execution loop ~~~
     * counter = 0, add init key
     * counter = 1 - 9, subBytes, shiftRows, mixColumns, addRoundKey
     * counter = 10, subBytes, shiftRows, addRoundkey
     */
    for(int counter = 0; counter <= 10; counter++){
	if(counter == 0){
	    addRoundKey(input, roundKey);
	    // ~~~~~!!!!! TEST PRINT STATEMENT !!!!!~~~~~
	    cout << "Round " << counter << " Resuts:" << endl;
	    for(int counter2 = 0; counter2 < 16; counter2++){
		cout << counter2 << ": ";
		cout << hex << (int)input[counter2] << dec << endl;
	    }
	    // ~~~~~!!!!! TEST PRINT STATEMENT !!!!!~~~~~
	}
	else if(counter < 10){
	    subBytes(input, 16);
	    shiftRows(input);
	    mixColumns(input);
	    addRoundKey(input, roundKey + counter*16);
	}
	else{
	    subBytes(input, 16);
	    shiftRows(input);
	    addRoundKey(input, roundKey + counter*16);
	}
    }
}

