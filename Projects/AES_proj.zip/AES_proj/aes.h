using namespace std;

/* SubBytes
 * Takes in 1 input:
 *  - pointer to first element in round input
 *  - number of bytes to be subbed
 * Returns:
 *  - Nothing (modifies pointer values to swapped result)
 */
void subBytes(unsigned char* input, int numBytes){
    // The S-box for Rijndael
    const unsigned char sbox[256] =
    {
	0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76,
	0xCA, 0x82, 0xC9, 0x7D, 0xFA, 0x59, 0x47, 0xF0, 0xAD, 0xD4, 0xA2, 0xAF, 0x9C, 0xA4, 0x72, 0xC0,
	0xB7, 0xFD, 0x93, 0x26, 0x36, 0x3F, 0xF7, 0xCC, 0x34, 0xA5, 0xE5, 0xF1, 0x71, 0xD8, 0x31, 0x15,
	0x04, 0xC7, 0x23, 0xC3, 0x18, 0x96, 0x05, 0x9A, 0x07, 0x12, 0x80, 0xE2, 0xEB, 0x27, 0xB2, 0x75,
	0x09, 0x83, 0x2C, 0x1A, 0x1B, 0x6E, 0x5A, 0xA0, 0x52, 0x3B, 0xD6, 0xB3, 0x29, 0xE3, 0x2F, 0x84,
	0x53, 0xD1, 0x00, 0xED, 0x20, 0xFC, 0xB1, 0x5B, 0x6A, 0xCB, 0xBE, 0x39, 0x4A, 0x4C, 0x58, 0xCF,
	0xD0, 0xEF, 0xAA, 0xFB, 0x43, 0x4D, 0x33, 0x85, 0x45, 0xF9, 0x02, 0x7F, 0x50, 0x3C, 0x9F, 0xA8,
	0x51, 0xA3, 0x40, 0x8F, 0x92, 0x9D, 0x38, 0xF5, 0xBC, 0xB6, 0xDA, 0x21, 0x10, 0xFF, 0xF3, 0xD2,
	0xCD, 0x0C, 0x13, 0xEC, 0x5F, 0x97, 0x44, 0x17, 0xC4, 0xA7, 0x7E, 0x3D, 0x64, 0x5D, 0x19, 0x73,
	0x60, 0x81, 0x4F, 0xDC, 0x22, 0x2A, 0x90, 0x88, 0x46, 0xEE, 0xB8, 0x14, 0xDE, 0x5E, 0x0B, 0xDB,
	0xE0, 0x32, 0x3A, 0x0A, 0x49, 0x06, 0x24, 0x5C, 0xC2, 0xD3, 0xAC, 0x62, 0x91, 0x95, 0xE4, 0x79,
	0xE7, 0xC8, 0x37, 0x6D, 0x8D, 0xD5, 0x4E, 0xA9, 0x6C, 0x56, 0xF4, 0xEA, 0x65, 0x7A, 0xAE, 0x08,
	0xBA, 0x78, 0x25, 0x2E, 0x1C, 0xA6, 0xB4, 0xC6, 0xE8, 0xDD, 0x74, 0x1F, 0x4B, 0xBD, 0x8B, 0x8A,
	0x70, 0x3E, 0xB5, 0x66, 0x48, 0x03, 0xF6, 0x0E, 0x61, 0x35, 0x57, 0xB9, 0x86, 0xC1, 0x1D, 0x9E,
	0xE1, 0xF8, 0x98, 0x11, 0x69, 0xD9, 0x8E, 0x94, 0x9B, 0x1E, 0x87, 0xE9, 0xCE, 0x55, 0x28, 0xDF,
	0x8C, 0xA1, 0x89, 0x0D, 0xBF, 0xE6, 0x42, 0x68, 0x41, 0x99, 0x2D, 0x0F, 0xB0, 0x54, 0xBB, 0x16
    };
    // For all bytes, find the replacement 
    for(int counter = 0; counter < numBytes; counter++){
	input[counter] = sbox[(int)input[counter]];
    }
}
/* RoundKeyGen
 * Takes in 1 input
 *  - pointer to first element in roundKey array
 *    -> array must have space for fully expanded key (256 bits * 11)
 *    -> Ex: unsigned char roundKey[176] = {roundkeydata};
 *           roundKeyGen(&roundKey[0])
 * Returns:
 *  - Nothing (modifies pointer values to contain fully expanded RoundKey)
 */
void roundKeyGen(unsigned char* roundKey){
    unsigned char temp[4];
    unsigned char Rcon = 0x01;
    for(int counter = 0; counter < 11; counter++){
	// Rotate last column of last round
	temp[0] = roundKey[13 + counter*16];
	temp[1] = roundKey[14 + counter*16];
	temp[2] = roundKey[15 + counter*16];
	temp[3] = roundKey[12 + counter*16];
	// SubBytes
	subBytes(&temp[0], 4);
	// XOR with first column of last round and Rcon value
	// Result: first column of this round
	roundKey[(counter+1)*16] = temp[0]^roundKey[counter*16]^Rcon;
	if(Rcon == 0x80)
	    Rcon = 0x1b;
	else
	    Rcon = Rcon << 1;
	roundKey[((counter+1)*16) + 1] = temp[1]^roundKey[1 + counter*16];
	roundKey[((counter+1)*16) + 2] = temp[2]^roundKey[2 + counter*16];
	roundKey[((counter+1)*16) + 3] = temp[3]^roundKey[3 + counter*16];
	// XOR first column of this round with second column of last round
	// Result: second column of this round
	roundKey[((counter+1)*16) + 4] = roundKey[(counter+1)*16]^roundKey[counter*16 + 4];
	roundKey[((counter+1)*16) + 5] = roundKey[((counter+1)*16) + 1]^roundKey[counter*16 + 5];
	roundKey[((counter+1)*16) + 6] = roundKey[((counter+1)*16) + 2]^roundKey[counter*16 + 6];
	roundKey[((counter+1)*16) + 7] = roundKey[((counter+1)*16) + 3]^roundKey[counter*16 + 7];
	// XOR second column of this round with third column of last round
	// Result: third column of this round
	roundKey[((counter+1)*16) + 8] = roundKey[((counter+1)*16) + 4]^roundKey[counter*16 + 8];
	roundKey[((counter+1)*16) + 9] = roundKey[((counter+1)*16) + 5]^roundKey[counter*16 + 9];
	roundKey[((counter+1)*16) + 10] = roundKey[((counter+1)*16) + 6]^roundKey[counter*16 + 10];
	roundKey[((counter+1)*16) + 11] = roundKey[((counter+1)*16) + 7]^roundKey[counter*16 + 11];
	// XOR third column of this round with forth clumn of last round
	// Result: forth column of this round
	roundKey[((counter+1)*16) + 12] = roundKey[((counter+1)*16) + 8]^roundKey[counter*16 + 12];
	roundKey[((counter+1)*16) + 13] = roundKey[((counter+1)*16) + 9]^roundKey[counter*16 + 13];
	roundKey[((counter+1)*16) + 14] = roundKey[((counter+1)*16) + 10]^roundKey[counter*16 + 14];
	roundKey[((counter+1)*16) + 15] = roundKey[((counter+1)*16) + 11]^roundKey[counter*16 + 15];
    }
/*
    // ~~~~~!!!!! Print out round keys !!!!!~~~~~
    for(int counter = 0; counter < 11; counter++){
	cout << "Round Key: " << counter << endl;
	for(int counter2 = 0; counter2 < 16; counter2++){
	    cout << counter2 << ": ";
	    cout << hex << (int)roundKey[counter2 + counter*16] << dec << endl;
	}
    }
*/
}
/* AddRoundKey
 * Takes in 2 inputs:
 *  - pointer to first element in round input
 *  - pointer to first element of the round in expanded round key
 * Returns:
 *  - Nothing (modifies pointer values to xor'd result)
 */
void addRoundKey(unsigned char* input, unsigned char* roundKey){
    for(int counter = 0; counter < 16; counter++){
	input[counter] = input[counter]^roundKey[counter];
    }
}
/* ShiftRows
 * Takes in 1 input:
 *  - pointer to first element in round input
 * Returns:
 *  - Nothing (modifies pointer values to shifted outputs)
 */
void shiftRows(unsigned char* input){
    unsigned char temp;
    // First row  (0, 4, 8, 12)   - unchanged
    // Second row (1, 5, 9, 13)   - shift 1
    temp = input[1];
    input[1] = input[5];
    input[5] = input[9];
    input[9] = input[13];
    input[13] = temp;
    // Third row  (2, 6, 10, 14)  - shift 2
    temp = input[2];
    input[2] = input[10];
    input[10] = temp;
    temp = input[6];
    input[6] = input[14];
    input[14] = temp;
    // Fourth row (3, 7, 11, 15) - shift 3
    temp = input[15];
    input[15] = input[11];
    input[11] = input[7];
    input[7] = input[3];
    input[3] = temp;
}
/* MixColumns Multiply by 2
 * Takes in 1 input:
 *  - char value that needs to be modified
 * Returns:
 *  - modified char value
 */
char mc2(char input){
    // Check if MSB is a 1
    // If 0, just shift 1 bit
    if((unsigned int) input > 128)
	return (input << 1)^0x1B;
    // If 1, shift 1 bit and XOR with 0x1B
    else
	return (input << 1);
}
/* MixColumns Multiply by 3
 * Takes in 1 input:
 *  - char value that needs to by modified
 * Returns:
 *  - modified char value
 */
char mc3(char input){
    // Perform mc2 operation
    char x;
    x = mc2(input);
    // XOR with original value
    return x^input;
}
/* MixColumns
 * Takes in 1 input:
 *  - pointer to first element in round input
 * Returns:
 *  - Nothing (modifies pointer values to shifted outputs)
 */
void mixColumns(unsigned char* input){
    /* The matrix for mixColumns
     * [r0] = [i0] [ 2, 3, 1, 1 ]
     * [r1] = [i1] [ 1, 2, 3, 1 ]
     * [r2] = [i2] [ 1, 1, 2, 3 ]
     * [r3] = [i3] [ 3, 1, 1, 2 ]
     * multiply by 1 = no change
     * multiply by 2 = shift left 1 bit & XOR with 0x1B (ONLY XOR IF 1 OVERFLOW)
     * multiply by 3 = multiply by 2 XOR multiply by 1
     */
    char oj[4];
    for(int counter = 0; counter < 4; counter++){
	oj[0] = input[0+4*counter];
	oj[1] = input[1+4*counter];
	oj[2] = input[2+4*counter];
	oj[3] = input[3+4*counter];
	input[0+4*counter] = mc2(oj[0]) ^ mc3(oj[1]) ^ oj[2] ^ oj[3];
	input[1+4*counter] = oj[0] ^ mc2(oj[1]) ^ mc3(oj[2]) ^ oj[3];
	input[2+4*counter] = oj[0] ^ oj[1] ^ mc2(oj[2]) ^ mc3(oj[3]);
	input[3+4*counter] = mc3(oj[0]) ^ oj[1] ^ oj[2] ^ mc2(oj[3]);
    }
}
